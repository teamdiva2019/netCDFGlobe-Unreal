// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "GameFramework/GameMode.h"
#include "DynamicTextureSampleGameMode.generated.h"

/**
 * 
 */
UCLASS()
class DYNAMICTEXTURESAMPLE_API ADynamicTextureSampleGameMode : public AGameMode
{
	GENERATED_BODY()
	
	
	
	
};
